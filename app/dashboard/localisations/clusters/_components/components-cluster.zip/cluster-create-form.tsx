"use client"

import { z } from "zod"
import { useForm, Controller } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { toast } from "sonner"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select"
import { createCluster } from "@/lib/api/clusters"
import { MultiSelect } from "@/components/ui/multi-select" // composant custom basé sur shadcn/ui
import { TiptapEditor } from "@/components/ui/tiptap-editor" // éditeur WYSIWYG personnalisé

// 🔹 Fausse liste de bâtiments simulée
const fakeBuildings = [
  { id: "b1", name: "Bâtiment A - Paris 11e" },
  { id: "b2", name: "Bâtiment B - Lyon Part-Dieu" },
  { id: "b3", name: "Entrepôt C - Marseille" },
];

const schema = z.object({
  name: z.string().min(2, "Nom requis"),
  description: z.string().optional(),
  localisation: z.string().optional(),
  couleur: z.string().regex(/^#([0-9A-Fa-f]{6})$/, "Couleur invalide (ex: #1A2B3C)").optional(),
  statut: z.enum(["actif", "inactif", "archive"]),
  tag: z.string().optional(),
  clientId: z.string().min(1, "Client requis"),
  buildingIds: z.array(z.string()).optional()
})

type FormData = z.infer<typeof schema>

interface Props {
  onSuccess?: () => void
  clients?: { id: string; name: string }[]
}

export function ClusterCreateForm({ onSuccess, clients = [] }: Props) {
  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      description: "",
      localisation: "",
      couleur: "#A1A1A1",
      statut: "actif",
      tag: "",
      clientId: clients[0]?.id || "",
      buildingIds: []
    }
  })

  const {
    control,
    handleSubmit,
    setValue,
    formState: { isSubmitting }
  } = form

  const onSubmit = async (data: FormData) => {
    await createCluster(data)
    toast.success("Cluster créé avec succès")
    onSuccess?.()
  }

  return (
    <Form {...form}>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nom</FormLabel>
                <FormControl><Input {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={control}
            name="statut"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Statut</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Statut" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="actif">Actif</SelectItem>
                    <SelectItem value="inactif">Inactif</SelectItem>
                    <SelectItem value="archive">Archivé</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description (éditeur riche)</FormLabel>
              <FormControl>
                <TiptapEditor value={field.value} onChange={field.onChange} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={control}
            name="localisation"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Localisation</FormLabel>
                <FormControl><Input placeholder="Ex: Paris 11e" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={control}
            name="couleur"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Couleur</FormLabel>
                <FormControl><Input type="color" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={control}
          name="tag"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tag</FormLabel>
              <FormControl><Input placeholder="Ex: zone nord" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="clientId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Client</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger><SelectValue placeholder="Client" /></SelectTrigger>
                </FormControl>
                <SelectContent>
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* 🏢 Sélection des bâtiments */}
        <FormField
          control={control}
          name="buildingIds"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Bâtiments liés</FormLabel>
              <MultiSelect
                options={fakeBuildings.map(b => ({ label: b.name, value: b.id }))}
                values={field.value || []}
                onChange={field.onChange}
              />
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full mt-6" disabled={isSubmitting}>
          Créer le cluster
        </Button>
      </form>
    </Form>
  )
}
