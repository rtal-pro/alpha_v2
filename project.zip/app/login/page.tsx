export default function LoginPage() {
  return (
    <div>
      <h1>Login</h1>
      <p>Here you can login.</p>
    </div>
  );
}