export default function SpotsPage() {
  return (
    <div className="flex flex-row h-full">
      <h1>Spots Page</h1>
    </div>
  );
}
