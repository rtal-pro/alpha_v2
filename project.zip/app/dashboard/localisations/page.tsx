export default function LocalisationPage() {
  return (
    <div className="flex flex-row h-full">
      <h1>Localisation Page</h1>
    </div>
  );
}