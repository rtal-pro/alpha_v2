"use client"

import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  MouseSensor,
  TouchSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core"
import {
  SortableContext,
  arrayMove,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  flexRender,
  ColumnDef,
} from "@tanstack/react-table"
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { SheetClusterDetails } from "./cluster-sheet"
import { ComponentType, JSXElementConstructor, Key, ReactElement, ReactNode, ReactPortal, useState } from "react"
import { GripVerticalIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface Cluster {
  id: string
  name: string
  label?: string
  status?: "actif" | "inactif"
  buildingCount: number
  spotCount: number
  ownerName?: string
  upcomingTasks?: number
}

interface Props {
  data: Cluster[]
  filters?: {
    search?: string
    status?: string | null
  }
}

export function ClusterDataTable({ data, filters }: Props) {
  const [rows, setRows] = useState(data)
  const sensors = useSensors(
    useSensor(MouseSensor),
    useSensor(TouchSensor),
    useSensor(KeyboardSensor)
  )

  const filteredRows = rows.filter((cluster) => {
    const matchSearch = filters?.search
      ? cluster.name.toLowerCase().includes(filters.search.toLowerCase())
      : true
    const matchStatus = filters?.status ? cluster.status === filters.status : true
    return matchSearch && matchStatus
  })

  const columns: ColumnDef<Cluster>[] = [
    {
      id: "sort",
      header: () => null,
      cell: () => <GripVerticalIcon className="w-4 h-4 text-muted-foreground cursor-grab" />,
    },
    {
      accessorKey: "name",
      header: "Nom",
      cell: ({ row }) => (
        <div className="font-medium text-foreground">
          {row.original.name}
        </div>
      ),
    },
    {
      accessorKey: "label",
      header: "Label",
      cell: ({ row }) => (
        <span className="text-xs text-muted-foreground">
          {row.original.label || "—"}
        </span>
      ),
    },
    {
      accessorKey: "status",
      header: "Statut",
      cell: ({ row }) => (
        <span
          className={cn(
            "text-xs font-medium",
            row.original.status === "actif" ? "text-green-600" : "text-red-500"
          )}
        >
          {row.original.status}
        </span>
      ),
    },
    {
      accessorKey: "buildingCount",
      header: "Bâtiments",
    },
    {
      accessorKey: "spotCount",
      header: "Spots",
    },
    {
      accessorKey: "ownerName",
      header: "Responsable",
      cell: ({ row }) => <span>{row.original.ownerName || "—"}</span>,
    },
    {
      id: "actions",
      header: "",
      cell: ({ row }) => <SheetClusterDetails cluster={row.original} />,
    },
  ]

  const table = useReactTable({
    data: filteredRows,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  })

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event
    if (active.id !== over?.id) {
      const oldIndex = rows.findIndex((r) => r.id === active.id)
      const newIndex = rows.findIndex((r) => r.id === over?.id)
      setRows((prev) => arrayMove(prev, oldIndex, newIndex))
    }
  }

  return (
    <div className="mt-2">
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={filteredRows.map((r) => r.id)} strategy={verticalListSortingStrategy}>
          <Table>
            <TableHeader>
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id}>
                  {headerGroup.headers.map((header) => (
                    <TableHead key={header.id}>
                      {flexRender(header.column.columnDef.header, header.getContext())}
                    </TableHead>
                  ))}
                </TableRow>
              ))}
            </TableHeader>
            <TableBody>
              {table.getRowModel().rows.map((row) => (
                <DraggableRow key={row.id} row={row} />
              ))}
            </TableBody>
          </Table>
        </SortableContext>
      </DndContext>
    </div>
  )
}

function DraggableRow({ row }: { row: any }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: row.original.id })
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <TableRow ref={setNodeRef} style={style} {...attributes}>
      {row.getVisibleCells().map((cell: { id: Key | null | undefined; column: { id: string; columnDef: { cell: string | number | bigint | boolean | ComponentType<any> | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | Promise<string | number | bigint | boolean | ReactPortal | ReactElement<unknown, string | JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined } }; getContext: () => any }) => (
        <TableCell key={cell.id} {...(cell.column.id === "sort" ? listeners : {})}>
          {flexRender(cell.column.columnDef.cell, cell.getContext())}
        </TableCell>
      ))}
    </TableRow>
  )
}
