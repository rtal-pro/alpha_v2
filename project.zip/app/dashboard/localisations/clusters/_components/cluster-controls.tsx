import { SetStateAction, useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  ToggleGroup,
  ToggleGroupItem,
} from "@/components/ui/toggle-group"
import { Table, LayoutGrid } from "lucide-react"

interface ClusterControlsProps {
  onViewChange?: (value: string) => void;
  onSearch?: (value: string) => void;
  onFilterChange?: (type: string, value: string) => void;
}

export function ClusterControls({ onViewChange, onSearch, onFilterChange }: ClusterControlsProps) {
  const [view, setView] = useState("card")
  const [search, setSearch] = useState("")

  const handleViewChange = (value: SetStateAction<string>) => {
    if (typeof value === "string") {
      setView(value)
      onViewChange?.(value)
    }
  }

  const handleSearchChange = (e: { target: { value: SetStateAction<string> } }) => {
    setSearch(e.target.value)
    onSearch?.(e.target.value as string)
  }

  const handleFilter = (type: string, value: string) => {
    onFilterChange?.(type, value)
  }

  return (
    <div className="w-full flex flex-col gap-4 mb-6">
      {/* Barre supérieure : recherche + filtres */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Recherche */}
        <Input
          placeholder="Rechercher un cluster..."
          value={search}
          onChange={handleSearchChange}
          className="w-full md:w-1/3"
        />

        {/* Filtres */}
        <div className="flex gap-2">
          {/* Filtre statut */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">Statut</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {['Actif', 'Inactif', 'En attente'].map((status) => (
                <DropdownMenuItem
                  key={status}
                  onClick={() => handleFilter("statut", status)}
                >
                  {status}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Filtre type de cluster */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">Type</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {['Industriel', 'Résidentiel', 'Commercial'].map((type) => (
                <DropdownMenuItem
                  key={type}
                  onClick={() => handleFilter("type", type)}
                >
                  {type}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Toggle vue Card/Table */}
      <div className="flex items-center justify-end">
        <ToggleGroup type="single" value={view} onValueChange={handleViewChange}>
          <ToggleGroupItem value="card" aria-label="Vue carte">
            <LayoutGrid className="w-5 h-5" />
          </ToggleGroupItem>
          <ToggleGroupItem value="table" aria-label="Vue table">
            <Table className="w-5 h-5" />
          </ToggleGroupItem>
        </ToggleGroup>
      </div>
    </div>
  )
}
