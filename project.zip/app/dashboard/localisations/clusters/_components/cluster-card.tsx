"use client"

import { Card, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Building2, Circle, MapPin, User, ListChecks } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { SheetClusterDetails } from "./cluster-sheet"

interface Cluster {
  id: string
  name: string
  label?: string
  status?: "actif" | "inactif"
  buildingCount: number
  spotCount: number
  ownerName?: string
  upcomingTasks?: number
  buildings?: {
    id: string
    name: string
    label?: string
    spotCount: number
  }[]
}

export function ClusterCard({ cluster }: { cluster: Cluster }) {
  const statusColor = cluster.status === "actif" ? "text-green-500" : "text-red-500"

  return (
    <Card key={cluster.id} className="relative border overflow-hidden group hover:shadow-lg transition">
      {/* Colored left bar */}
      <div className="absolute top-0 left-0 w-0.5 h-full bg-[var(--color-secondary)]" />

      <div className="flex flex-col gap-4 p-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="w-3.5 h-3.5 rounded-full border border-[var(--color-border)] flex items-center justify-center">
                    <Circle className={cn("w-2.5 h-2.5", statusColor)} fill="currentColor" />
                  </div>
                </TooltipTrigger>
                <TooltipContent side="top" className="text-xs">
                  {cluster.status === "actif" ? "Cluster actif" : "Cluster inactif"}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <CardTitle className="text-lg text-primary flex items-center gap-2">
              {cluster.name}
            </CardTitle>
          </div>

          <SheetClusterDetails cluster={cluster} />
        </div>

        {cluster.label && (
          <Badge variant="secondary" className="w-fit">
            {cluster.label}
          </Badge>
        )}

        {/* Stats block */}
        <div className="text-sm text-muted-foreground flex gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[var(--color-secondary)]" />
            <span><strong>{cluster.buildingCount}</strong> bâtiments</span>
          </div>
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-[var(--color-secondary)]" />
            <span>{cluster.ownerName ?? "Non défini"}</span>
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <ListChecks className="w-4 h-4 text-[var(--color-secondary)]" />
            <span><strong>{cluster.upcomingTasks ?? 0}</strong> tâches</span>
          </div>
        </div>

        {/* Bâtiments */}
        <div>
          <p className="text-sm font-semibold mb-2 text-secondary-foreground">Bâtiments :</p>
          {cluster.buildings?.length ? (
            <div className="flex flex-wrap gap-2">
              {cluster.buildings.map((b) => (
                <Link key={b.id} href={`/buildings/${b.id}`}>
                  <Button
                    variant="outline"
                    size="sm"
                    className="justify-between border-[1.5px] min-w-[150px] px-3"
                    style={{
                      borderColor: "var(--color-secondary)",
                      color: "var(--color-secondary)",
                    }}
                  >
                    <span>{b.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {b.spotCount} spots – {b.label}
                    </span>
                  </Button>
                </Link>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground italic">Aucun bâtiment.</p>
          )}
        </div>
      </div>
    </Card>
  )
}
