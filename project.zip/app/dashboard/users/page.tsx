export default function UsersPage() {
  return (
    <div>
      <h1>Users</h1>
      <p>Here you can manage your users.</p>
    </div>
  );
}