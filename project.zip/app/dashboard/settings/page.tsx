export default function SettingsPage() {
  return (
    <div>
      <h1>Settings</h1>
      <p>Here you can manage your settings.</p>
    </div>
  );
}
