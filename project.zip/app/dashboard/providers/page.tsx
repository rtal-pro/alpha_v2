export default function ProvidersPage() {
  return (
    <div>
      <h1>Prestataires</h1>
      <p>Here you can manage your providers.</p>
    </div>
  );
}
