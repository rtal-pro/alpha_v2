export default function InternalPage() {
  return (
    <div>
      <h1>Internal</h1>
      <p>Here you can manage your internals.</p>
    </div>
  );
}