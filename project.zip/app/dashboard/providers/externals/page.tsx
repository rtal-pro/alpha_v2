export default function ExternalPage() {
  return (
    <div>
      <h1>External</h1>
      <p>Here you can manage your externals.</p>
    </div>
  );
}