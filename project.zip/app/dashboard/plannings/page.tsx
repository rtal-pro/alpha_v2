export default function PlanningPage() {
  return (
    <div>
      <h1>Planning</h1>
      <p>Here you can manage your planning.</p>
    </div>
  );
}